Je n'ai pas été capable de forcer l'ajout du dossier a21-final avec git bash

Même en changeant le .gitignore et en forçant l'ajout avec --force et -f, git ne voulait pas ajouter le répertoire.
Ducoup, j'ai zipé le projet, il faut comme même faire npm i pour react, car j'ai supprimé node_modules