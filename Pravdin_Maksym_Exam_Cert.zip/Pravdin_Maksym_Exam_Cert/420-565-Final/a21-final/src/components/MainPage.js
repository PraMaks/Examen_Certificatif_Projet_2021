import React, { useState } from "react";
import "../styles/TableStyles.css";

const MainPage = () => {
  const [clients, setClients] = useState([]);

  const fetchAllClients = async () => {
    fetch("http://localhost:8080/getAllClients/")
      .then((res) => res.json())
      .then(
        (result) => {
          setClients(result);
        },
        (error) => {
          console.log(error);
        }
      );
  };

  const FetchAllMaleClients = async () => {
    fetch("http://localhost:8080/getAllClients/male")
      .then((res) => res.json())
      .then(
        (result) => {
          setClients(result);
        },
        (error) => {
          console.log(error);
        }
      );
  };

  const FetchAllClientsInOntario = async () => {
    fetch("http://localhost:8080/getAllClients/Ontario")
      .then((res) => res.json())
      .then(
        (result) => {
          setClients(result);
        },
        (error) => {
          console.log(error);
        }
      );
  };

  return (
    <>
      <button onClick={fetchAllClients}>Fetch tous les clients</button>

      <button onClick={FetchAllMaleClients}>Fetch les hommes</button>

      <button onClick={FetchAllClientsInOntario}>Fetch les Ontariens</button>

      <h1>TABLE DES CLIENTS</h1>

      <table>
        <tr>
          <th>ID</th>
          <th>FIRST NAME</th>
          <th>LAST NAME</th>
          <th>GENDER</th>
          <th>BIRTH DATE</th>
        </tr>
        {clients.map((client) => (
          <tr key={client.id}>
            <td>{client.id}</td>
            <td>{client.firstName}</td>
            <td>{client.lastName}</td>
            <td>{client.gender}</td>
            <td>{client.birthDate}</td>
          </tr>
        ))}
      </table>
    </>
  );
};
export default MainPage;
