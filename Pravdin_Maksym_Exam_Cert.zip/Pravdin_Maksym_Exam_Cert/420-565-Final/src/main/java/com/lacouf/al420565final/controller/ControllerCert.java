package com.lacouf.al420565final.controller;

import com.lacouf.al420565final.model.Client;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.lacouf.al420565final.util.ClientFactory.getClients;

@RestController
@CrossOrigin("http://localhost:3000")
public class ControllerCert {

    @GetMapping("/getAllClients")
    public ResponseEntity<List<Client>> getAllClients() {
        List<Client> liste = getClients();
        return Optional.of(liste)
                .map(_client -> ResponseEntity.status(HttpStatus.ACCEPTED).body(_client))
                .orElse(ResponseEntity.status(HttpStatus.CONFLICT).build());
    }

    @GetMapping("/getAllClients/male")
    public ResponseEntity<List<Client>> getAllMaleClients() {
        List<Client> listeInitiale = getClients();
        List<Client> listeFiltree = listeInitiale
                .stream()
                .filter(client -> client.getGender().equals("M"))
                .collect(Collectors.toList());
        return Optional.of(listeFiltree)
                .map(_client -> ResponseEntity.status(HttpStatus.ACCEPTED).body(_client))
                .orElse(ResponseEntity.status(HttpStatus.CONFLICT).build());
    }

    @GetMapping("/getAllClients/Ontario")
    public ResponseEntity<List<Client>> getAllClientsInOntario() {
        List<Client> listeInitiale = getClients();
        List<Client> listeFiltree = listeInitiale
                .stream()
                .filter(client -> client.getProvince().equals("ON"))
                .collect(Collectors.toList());
        return Optional.of(listeFiltree)
                .map(_client -> ResponseEntity.status(HttpStatus.ACCEPTED).body(_client))
                .orElse(ResponseEntity.status(HttpStatus.CONFLICT).build());
    }
}
